'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import AuthForm from '../components/AuthForm'

export default function LoginPage() {
  const router = useRouter()

  useEffect(() => {
    const currentUser = localStorage.getItem('currentUser')
    if (currentUser) {
      router.push('/')
    }
  }, [router])

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <AuthForm />
    </div>
  )
}

