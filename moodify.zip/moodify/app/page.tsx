'use client'

import { useEffect, useState } from 'react'
import { useAudio } from './contexts/AudioContext'
import { Button } from "@/components/ui/button"
import MoodDetector from './components/MoodDetector'
import { Play } from 'lucide-react'

const sampleSongs = [
  { id: 1, title: "Sunny Day", artist: "Happy Band", album: "Summer Vibes", duration: 180, cover: "/images/album-1.jpg" },
  { id: 2, title: "Rainy Mood", artist: "Chill Collective", album: "Relaxation", duration: 210, cover: "/images/album-2.jpg" },
  { id: 3, title: "Energetic Morning", artist: "Power Trio", album: "Wake Up", duration: 160, cover: "/images/album-3.jpg" },
  { id: 4, title: "Calm Evening", artist: "Smooth Jazz Ensemble", album: "Night Whispers", duration: 240, cover: "/images/album-4.jpg" },
  { id: 5, title: "Upbeat Afternoon", artist: "Pop Stars", album: "Midday Magic", duration: 200, cover: "/images/album-5.jpg" },
]

export default function Home() {
  const { play, currentSong, isPlaying, pause, resume } = useAudio()
  const [user, setUser] = useState<{ email: string } | null>(null)

  useEffect(() => {
    const currentUser = localStorage.getItem('currentUser')
    if (currentUser) {
      setUser(JSON.parse(currentUser))
    }
  }, [])

  if (!user) return null

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-4">Welcome to Moodify, {user.email}!</h1>
      <p className="text-xl mb-8">Discover music that matches your mood!</p>
      <MoodDetector />
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Recommended for You</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {sampleSongs.map((song) => (
            <div key={song.id} className="bg-gray-800 rounded-lg overflow-hidden transition-transform transform hover:scale-105">
              <img src={song.cover} alt={`${song.album} Cover`} className="w-full aspect-square object-cover" />
              <div className="p-4">
                <h3 className="font-semibold">{song.title}</h3>
                <p className="text-sm text-gray-400">{song.artist}</p>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="mt-2"
                  onClick={() => currentSong?.id === song.id && isPlaying ? pause() : play(song)}
                >
                  {currentSong?.id === song.id && isPlaying ? (
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" />
                    </svg>
                  ) : (
                    <Play className="w-6 h-6" />
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="text-2xl font-semibold mb-4">Recently Played</h2>
        <div className="space-y-4">
          {sampleSongs.map((song) => (
            <div key={song.id} className="flex items-center bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition-colors">
              <img src={song.cover} alt={`${song.album} Cover`} className="w-16 h-16 rounded mr-4" />
              <div>
                <h3 className="font-semibold">{song.title}</h3>
                <p className="text-sm text-gray-400">{song.artist}</p>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="ml-auto"
                onClick={() => currentSong?.id === song.id && isPlaying ? pause() : play(song)}
              >
                {currentSong?.id === song.id && isPlaying ? (
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" />
                  </svg>
                ) : (
                  <Play className="w-6 h-6" />
                )}
              </Button>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

