'use client'

import { useState } from 'react'
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState('')

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement search logic here
    console.log('Searching for:', searchQuery)
  }

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-8">Search</h1>
      <form onSubmit={handleSearch} className="mb-8">
        <div className="flex gap-4">
          <Input
            type="text"
            placeholder="Search for songs, artists, or albums"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-grow"
          />
          <Button type="submit">Search</Button>
        </div>
      </form>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Sample search results */}
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition-colors">
            <img src={`/images/album-${i}.jpg`} alt={`Album ${i}`} className="w-full aspect-square object-cover rounded-lg mb-4" />
            <h3 className="font-semibold">Song Title {i}</h3>
            <p className="text-sm text-gray-400">Artist Name</p>
          </div>
        ))}
      </div>
    </div>
  )
}

