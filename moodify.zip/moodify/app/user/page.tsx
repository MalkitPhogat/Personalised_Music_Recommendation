'use client'

import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

// Mock user data (replace with actual user data in a real application)
const user = {
  name: "John Doe",
  email: "john@example.com",
  avatar: "/images/user-avatar.jpg",
  plan: "Premium",
  nextBillingDate: "June 1, 2023"
}

export default function UserPage() {
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated')
    router.push('/login')
  }

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-8">User Profile</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>Manage your account details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center mb-6">
              <img src={user.avatar} alt="User Avatar" className="w-24 h-24 rounded-full mr-6" />
              <div>
                <h2 className="text-2xl font-semibold">{user.name}</h2>
                <p className="text-gray-400">{user.email}</p>
              </div>
            </div>
            <Button>Edit Profile</Button>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Subscription</CardTitle>
            <CardDescription>Manage your Moodify subscription</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4">Current Plan: <span className="font-semibold">{user.plan}</span></p>
            <p className="mb-4">Next billing date: <span className="font-semibold">{user.nextBillingDate}</span></p>
            <Button variant="outline">Manage Subscription</Button>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Listening History</CardTitle>
            <CardDescription>View and manage your listening history</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <li key={i} className="flex items-center">
                  <img src={`/images/album-${i}.jpg`} alt={`Album ${i}`} className="w-12 h-12 rounded mr-4" />
                  <div>
                    <h3 className="font-semibold">Song Title {i}</h3>
                    <p className="text-sm text-gray-400">Artist Name</p>
                  </div>
                </li>
              ))}
            </ul>
            <Button className="mt-4">View Full History</Button>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Account Actions</CardTitle>
            <CardDescription>Manage your account settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full">Change Password</Button>
            <Button variant="outline" className="w-full">Delete Account</Button>
            <Button variant="destructive" className="w-full" onClick={handleLogout}>Logout</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

